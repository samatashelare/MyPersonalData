class Mac 
{
	public static void main(String args[])
	{
		int x[][][]={
			        {{10,20,30,40}},
				    {{11,12,13},{45,46}},
					{{47,48,49,50}}
		            };
					
					System.out.println(x);  //  [[[I@762efe5d
					System.out.println(x[0]); // [[I@71dac704
					System.out.println(x[0][0]); // [I@123772c4
					System.out.println(x[0][0][0]);// 10
					System.out.println(x.length); // 3
					System.out.println(x[0].length); // 1
					System.out.println(x[0][0].length); // 4
					
					
	}
}