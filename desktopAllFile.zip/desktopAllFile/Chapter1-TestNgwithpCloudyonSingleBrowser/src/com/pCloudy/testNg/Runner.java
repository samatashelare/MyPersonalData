package com.pCloudy.testNg;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.io.FileHandler;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.*;

public class Runner {

	RemoteWebDriver driver;
	DesiredCapabilities capabilities;
	String folder_name;
	DateFormat df;

	@BeforeTest
	public void setUpSuite() throws Exception {

	}

	@BeforeMethod
	public void prepareTest() throws IOException, InterruptedException {

//		capabilities =  DesiredCapabilities.firefox();
//		
//		
//		capabilities.setCapability("os", "Windows");
//		capabilities.setCapability("osVersion", "11");
//		capabilities.setCapability("browserVersion","116");
//		capabilities.setCapability("clientName", "https://manulife.pcloudy.com");
//		capabilities.setCapability("apiKey", "Xdb9HnE3CwuQP6VF");
//		capabilities.setCapability("email", "satyam.kumar@sstsinc.com");
//		capabilities.setCapability(	"timezone","America/Caracas");
////		caps.setCapability (CapabilityType.ACCEPT_SSL_CERTS, true);
//	    capabilities.setCapability("enableWildnet", true);
//		capabilities.setCapability("idleTimeout", 120);
//		
//		driver = new RemoteWebDriver(new URL("https://manulife-browsercloud-in.pcloudy.com/seleniumcloud/wd/hub"), capabilities);

//		 driver = new RemoteWebDriver.Builder()
//			     .forBrowser("chrome")
//			     .build();

		DesiredCapabilities capabilities = new DesiredCapabilities();
		capabilities.setCapability("browserName", "safari");
		capabilities.setCapability("clientName", "wihov81285@nimadir.com");
	//	HashMap<String, Object> pcloudyOptions = new HashMap<String, Object>();
		capabilities.setCapability("email", "wihov81285@nimadir.com");
		capabilities.setCapability("apiKey", "8j2bdfwqstgn8w3kjj7brdwv");
		//capabilities.setCapability("clientName", "wihov81285@nimadir.com");
		capabilities.setCapability("os", "Mac");
		capabilities.setCapability("osVersion", "Sonoma");
		// capabilities.setCapability("browserVersion", "113");
		capabilities.setCapability("browserVersion", "108");
		// capabilities.setCapability("browserVersion", "109.0.5414.75");
		capabilities.setCapability("local", true);
		capabilities.setCapability("seleniumVersion", "3.141.59");
	//	capabilities.setCapability("pcloudy:options", pcloudyOptions);
		System.out.println(capabilities);
		driver = new RemoteWebDriver(new URL("https://dev2-browsercloud-in.pcloudy.com/seleniumcloud/wd/hub"), capabilities);

		// driver = new RemoteWebDriver(new URL("http://4.247.153.235:4444/wd/hub"),
		// capabilities);

		System.out.println("Browser Initiated");
		Thread.sleep(3000);

	}

	@Test // (invocationCount=2)
	public void Test() throws Exception {

		// WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
		driver.manage().window().maximize();

	/*	driver.get("http://192.168.1.45:8080/login?from=%2F");
		Thread.sleep(2000);
		System.out.println("Open the URL");*/

		driver.findElement(By.xpath("//input[@id='j_username']")).sendKeys("satyam");
		Thread.sleep(2000);
		System.out.println("Username");
		driver.findElement(By.xpath("//input[@id='j_password']")).sendKeys("satyam");
		Thread.sleep(2000);
		System.out.println("Password");
		driver.findElement(By.cssSelector("label[for='remember_me']")).click();
		Thread.sleep(2000);
		System.out.println("Select checkbox");
		driver.findElement(By.xpath(" //button[normalize-space()='Sign in']")).sendKeys("satyam");
		Thread.sleep(2000);
		System.out.println("wildnet pass");

//		    driver.get("https://www.linkedin.com/");
//		    Thread.sleep(3000);
//		    
//			driver.get("https://device.pcloudy.com/login");
//			Thread.sleep(3000);
//			System.out.println("open cloud url");
//			
//			driver.findElement(By.id("userId")).sendKeys("satyam.kumar@sstsinc.com");
//			Thread.sleep(3000);
//			captureScreenShots();
//			System.out.println("Pass email id");
//			
//			driver.findElement(By.name("password")).sendKeys("Satyam1");
//			Thread.sleep(3000);
//			System.out.println("enter password");
//			
//			driver.findElement(By.id("loginSubmitBtn")).click();
//			captureScreenShots(); 
//			System.out.println("SignedIn");
//			
//		    driver.get("https://device.pcloudy.com"); 
//			System.out.println("Pass");
//			Thread.sleep(3000);
	}

	// Get the WebElement corresponding to the Email Address(TextField)
	/*
	 * WebElement email = driver.findElement(By.id("userId")); captureScreenShots();
	 * 
	 * // Get the WebElement corresponding to the Password Field WebElement password
	 * = driver.findElement(By.name("password"));
	 * 
	 * email.sendKeys("satyam.kumar@sstsinc.com"); password.sendKeys("Satyam1#");
	 * System.out.println("Text Field Set"); captureScreenShots();
	 * 
	 * // Deleting values in the text box email.clear(); password.clear();
	 * System.out.println("Text Field Cleared");
	 * 
	 * // Find the submit button WebElement login =
	 * driver.findElement(By.id("loginSubmitBtn"));
	 * 
	 * // Using click method to submit form
	 * email.sendKeys("satyam.kumar@sstsinc.com"); password.sendKeys("Satyam1");
	 * login.click(); System.out.println("Login Done with Click");
	 * captureScreenShots();
	 */

	// using submit method to submit the form. Submit used on password field
	// driver.get(baseUrl);
	/*
	 * driver.findElement(By.id("email")).sendKeys("abcd@gmail.com");
	 * driver.findElement(By.name("passwd")).sendKeys("abcdefghlkjl");
	 * driver.findElement(By.id("SubmitLogin")).submit();
	 * System.out.println("Login Done with Submit");
	 */

	// driver.close();
	// }*/

	@AfterMethod
	public void afterMethod() throws InterruptedException {

		driver.quit();

	}

	public void captureScreenShots() throws Exception {

		folder_name = "screenshot";
		TakesScreenshot scrShot = ((TakesScreenshot) driver);
		File f = scrShot.getScreenshotAs(OutputType.FILE);
		df = new SimpleDateFormat("dd-MMM-yyyy__hh_mm_ssaa");
		// create dir with given folder name
		new File(folder_name).mkdir();
		// Setting file name
		String file_name = df.format(new Date()) + ".png";
		// copy screenshot file into screenshot folder.
		FileHandler.copy(f, new File(folder_name + "/" + file_name));

	}
}
